// About Us.js console.log("JavaScript connected");
/* =========================================================
   Sweet Crumbs Bakery - About Us JavaScript
   Features:
   1. Bakery statistics counter
   2. Team member information toggle
   3. Bakery history timeline
   ========================================================= */

/* ---------- 1. Bakery Statistics Counter ---------- */
const statistics = [
  {
    elementId: "years-in-business",
    targetValue: 12,
    suffix: "+"
  },
  {
    elementId: "products-baked",
    targetValue: 250,
    suffix: "+"
  },
  {
    elementId: "happy-customers",
    targetValue: 5000,
    suffix: "+"
  }
];

function animateCounter(element, targetValue, suffix) {
  let currentValue = 0;
  const increment = Math.ceil(targetValue / 50);

  const counterInterval = setInterval(function () {
    currentValue += increment;

    if (currentValue >= targetValue) {
      currentValue = targetValue;
      clearInterval(counterInterval);
    }

    element.textContent = currentValue + suffix;
  }, 40);
}

function startStatisticsCounters() {
  statistics.forEach(statistic => {
    const element = document.getElementById(statistic.elementId);

    if (element) {
      animateCounter(
        element,
        statistic.targetValue,
        statistic.suffix
      );
    }
  });
}

window.addEventListener("load", startStatisticsCounters);

/* ---------- 2. Team Member Information Toggle ---------- */
const teamButtons = document.querySelectorAll(".team-member-button");

teamButtons.forEach(button => {
  button.addEventListener("click", function () {
    const teamMemberCard = this.closest(".team-member-card");
    const teamMemberDetails =
      teamMemberCard.querySelector(".team-member-details");

    teamMemberCard.classList.toggle("active");

    if (teamMemberCard.classList.contains("active")) {
      teamMemberDetails.style.maxHeight =
        teamMemberDetails.scrollHeight + "px";
      this.textContent = "Hide Details";
    } else {
      teamMemberDetails.style.maxHeight = "0";
      this.textContent = "Show Details";
    }
  });
});

/* ---------- 3. Bakery History Timeline ---------- */
const timelineItems = document.querySelectorAll(".timeline-item");

function revealTimelineItems() {
  timelineItems.forEach(item => {
    const itemPosition = item.getBoundingClientRect().top;
    const screenPosition = window.innerHeight - 100;

    if (itemPosition < screenPosition) {
      item.classList.add("visible");
    }
  });
}

window.addEventListener("scroll", revealTimelineItems);
window.addEventListener("load", revealTimelineItems);