// Order Online.js console.log("JavaScript connected");

/* ---------- 1. Bakery Products ---------- */
const orderProducts = [
  {
    id: "birthday-cake",
    name: "Birthday Cake",
    price: 450
  },
  {
    id: "wedding-cake",
    name: "Wedding Cake",
    price: 520
  },
  {
    id: "floral-cake",
    name: "Floral theme Cake",
    price: 350
  },
  {
    id: "vanilla-cupcakes",
    name: "Vanilla Cupcakes",
    price: 120
  },
  {
    id: "croissants",
    name: "Croissants",
    price: 75
  }

  {
    id: "cinnamon-rolls",
    name: "Cinnamon Rolls",
    price: 120
  },
  {
    id: "fruit-tart",
    name: "Fruit Tart",
    price: 115
  },
  {
    id: "eclair",
    name: "Eclair",
    price: 45
  },
  {
    id: "kouign amonn",
    name: "Kouign-amonn",
    price: 40
  },
  {
    id: "sourdough",
    name: "Sourdough",
    price: 45
  }
  
  {
    id: "challah",
    name: "Challah",
    price: 50
  },
  {
    id: "baguette",
    name: "Baguette",
    price: 35
  },
  {
    id: "white-bread",
    name: "White Bread",
    price: 30
  },
  {
    id: "whole-wheat-bread",
    name: "Whole Wheat Bread",
    price: 35
  },
  {
    id: "rye",
    name: "Rye",
    price: 50
  }
   {
    id: "brioche",
    name: "Brioche",
    price: 50
  }

];

let customerOrder = [];

const orderItemsContainer = document.getElementById("order-items");
const orderTotalElement = document.getElementById("order-total");

/* ---------- Add Product to Order ---------- */
const addToOrderButtons =
  document.querySelectorAll(".add-to-order");

addToOrderButtons.forEach(button => {
  button.addEventListener("click", function () {
    const productId = this.dataset.id;

    const selectedProduct = orderProducts.find(
      product => product.id === productId
    );

    if (!selectedProduct) {
      alert("Product not found.");
      return;
    }

    /* Check whether the product is already in the order */
    const existingItem = customerOrder.find(
      item => item.id === productId
    );

    if (existingItem) {
      /* Increase quantity if product already exists */
      existingItem.quantity++;
    } else {
      /* Add new product to the order */
      customerOrder.push({
        id: selectedProduct.id,
        name: selectedProduct.name,
        price: selectedProduct.price,
        quantity: 1
      });
    }

    displayOrder();
  });
});

/* ---------- Display Order and Calculate Total ---------- */
function displayOrder() {
  orderItemsContainer.innerHTML = "";

  if (customerOrder.length === 0) {
    orderItemsContainer.innerHTML = `
      <p>Your order is currently empty.</p>
    `;

    orderTotalElement.textContent = "R0.00";
    return;
  }

  let orderTotal = 0;

  customerOrder.forEach(item => {
    const itemTotal = item.price * item.quantity;

    /* Add each item total to the overall order total */
    orderTotal += itemTotal;

    const orderItem = document.createElement("div");
    orderItem.className = "order-item";

    orderItem.innerHTML = `
      <p>
        <strong>${item.name}</strong><br>
        R${item.price.toFixed(2)} x ${item.quantity}
        = R${itemTotal.toFixed(2)}
      </p>

      <button
        class="remove-item"
        data-id="${item.id}"
      >
        Remove
      </button>
    `;

    orderItemsContainer.appendChild(orderItem);
  });

  /* Display the calculated total */
  orderTotalElement.textContent =
    "R" + orderTotal.toFixed(2);

  attachRemoveItemEvents();
}

/* ---------- Remove Product from Order ---------- */
function attachRemoveItemEvents() {
  const removeButtons =
    document.querySelectorAll(".remove-item");

  removeButtons.forEach(button => {
    button.addEventListener("click", function () {
      const productId = this.dataset.id;

      customerOrder = customerOrder.filter(
        item => item.id !== productId
      );

      displayOrder();
    });
  });
}
if (isNameValid && isEmailValid && isPhoneValid && isMessageValid) {
  const enquiryResponse = document.getElementById("enquiry-response");

  enquiryResponse.innerHTML = `
    <div class="success-message">
      <h3>Enquiry Received</h3>
      <p>
        Thank you, ${nameInput.value.trim()}.
        Your enquiry about ${productInput.value} has been received.
        We will contact you at ${emailInput.value.trim()} regarding
        availability and pricing.
      </p>
    </div>
  `;

  enquiryForm.reset();
}
/* ---------- Show Empty Order When Page Loads ---------- */
displayOrder();
/* ---------- 5. Validate Order and Continue to Payment ---------- */
function validateOrderForm(event) {
  event.preventDefault();

  const nameInput = document.getElementById("customer-name");
  const emailInput = document.getElementById("customer-email");
  const phoneInput = document.getElementById("customer-phone");
  const addressInput = document.getElementById("delivery-address");

  let isValid = true;

  function showError(input, message) {
    const errorElement =
      input.parentElement.querySelector(".error-message");

    errorElement.textContent = message;
    input.classList.add("invalid");
    isValid = false;
  }

  function clearError(input) {
    const errorElement =
      input.parentElement.querySelector(".error-message");

    errorElement.textContent = "";
    input.classList.remove("invalid");
  }

  if (nameInput.value.trim().length < 3) {
    showError(nameInput, "Please enter your full name.");
  } else {
    clearError(nameInput);
  }

  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (!emailPattern.test(emailInput.value.trim())) {
    showError(emailInput, "Please enter a valid email address.");
  } else {
    clearError(emailInput);
  }

  const phonePattern = /^[0-9+\s()-]{10,15}$/;

  if (!phonePattern.test(phoneInput.value.trim())) {
    showError(phoneInput, "Please enter a valid phone number.");
  } else {
    clearError(phoneInput);
  }

  if (addressInput.value.trim().length < 10) {
    showError(
      addressInput,
      "Please enter a complete delivery address."
    );
  } else {
    clearError(addressInput);
  }

  if (customerOrder.length === 0) {
    alert("Please add at least one bakery product to your order.");
    return;
  }

  if (isValid) {
    startOnlinePayment();
  }
}

if (orderForm) {
  orderForm.addEventListener("submit", validateOrderForm);
}


const thankYouModal = document.getElementById("thank-you-modal");
const closeThankYouButton = document.getElementById("close-thank-you");
const thankYouContinueButton =
  document.getElementById("thank-you-continue");
const thankYouMessage = document.getElementById("thank-you-message");

function openThankYouModal(customerName, orderTotal) {
  if (!thankYouModal) return;

  thankYouMessage.textContent =
    "Thank you, " + customerName + ". Your order of " +
    orderTotal + " has been received. Our bakery team will " +
    "contact you shortly to confirm your order and delivery details.";

  thankYouModal.classList.add("active");
  document.body.style.overflow = "hidden";
}

function closeThankYouModal() {
  if (!thankYouModal) return;

  thankYouModal.classList.remove("active");
  document.body.style.overflow = "";
}

if (closeThankYouButton) {
  closeThankYouButton.addEventListener("click", closeThankYouModal);
}

if (thankYouContinueButton) {
  thankYouContinueButton.addEventListener("click", closeThankYouModal);
}

if (thankYouModal) {
  thankYouModal.addEventListener("click", function (event) {
    if (event.target === thankYouModal) {
      closeThankYouModal();
    }
  });
}

document.addEventListener("keydown", function (event) {
  if (event.key === "Escape") {
    closeThankYouModal();
  }
});
/* ---------- 6. Online Payment ---------- */
function startOnlinePayment() {
  const orderTotalText = orderTotalElement.textContent;
  const orderAmount = parseFloat(
    orderTotalText.replace("R", "").replace(",", "")
  );

  const customerName = document
    .getElementById("customer-name")
    .value.trim();

  const customerEmail = document
    .getElementById("customer-email")
    .value.trim();

  /* Replace these values with your payment provider details */
  const paymentDetails = {
    merchant_id: "YOUR_MERCHANT_ID",
    merchant_key: "YOUR_MERCHANT_KEY",
    return_url: "https://yourwebsite.co.za/payment-success.html",
    cancel_url: "https://yourwebsite.co.za/payment-cancelled.html",
    notify_url: "https://yourwebsite.co.za/payment-notification.php",
    amount: orderAmount.toFixed(2),
    item_name: "Sweet Crumbs Bakery Order",
    customer_name: customerName,
    customer_email: customerEmail
  };

  const paymentForm = document.createElement("form");
  paymentForm.method = "POST";
  paymentForm.action =
    "https://sandbox.payfast.co.za/eng/process";

  Object.keys(paymentDetails).forEach(key => {
    const hiddenField = document.createElement("input");
    hiddenField.type = "hidden";
    hiddenField.name = key;
    hiddenField.value = paymentDetails[key];
    paymentForm.appendChild(hiddenField);
  });

  document.body.appendChild(paymentForm);
  paymentForm.submit();
}