// Reviews.js console.log("JavaScript connected");
/* =========================================================
   Sweet Crumbs Bakery - Customer Reviews JavaScript
   Features:
   1. Display customer reviews
   2. Add a new customer review
   3. Calculate average rating
   4. Filter reviews by rating
   ========================================================= */

/* ---------- 1. Customer Reviews Data ---------- */
let customerReviews = [
  {
    name: "Naledi M.",
    rating: 5,
    comment: "The chocolate fudge cake was fresh and delicious."
  },
  {
    name: "Sipho K.",
    rating: 4,
    comment: "Great bread and friendly service."
  },
  {
    name: "Aisha P.",
    rating: 5,
    comment: "My birthday cake looked beautiful and tasted amazing."
  }
];

const reviewsContainer = document.getElementById("reviews-container");
const averageRatingElement = document.getElementById("average-rating");
const reviewForm = document.getElementById("review-form");
const ratingFilter = document.getElementById("rating-filter");

/* ---------- 2. Display Reviews ---------- */
function displayReviews(reviews) {
  if (!reviewsContainer) return;

  reviewsContainer.innerHTML = "";

  if (reviews.length === 0) {
    reviewsContainer.innerHTML = `
      <p>No customer reviews match your selection.</p>
    `;
    return;
  }

  reviews.forEach(review => {
    const reviewCard = document.createElement("article");
    reviewCard.className = "review-card";

    reviewCard.innerHTML = `
      <h3>${review.name}</h3>
      <p class="review-rating">Rating: ${review.rating} / 5</p>
      <p>${review.comment}</p>
    `;

    reviewsContainer.appendChild(reviewCard);
  });
}

/* ---------- 3. Calculate Average Rating ---------- */
function calculateAverageRating() {
  if (customerReviews.length === 0) {
    averageRatingElement.textContent = "No ratings yet.";
    return;
  }

  const totalRating = customerReviews.reduce(
    (total, review) => total + review.rating,
    0
  );

  const averageRating = totalRating / customerReviews.length;

  averageRatingElement.textContent =
    "Average Rating: " + averageRating.toFixed(1) + " / 5";
}

/* ---------- 4. Add New Review ---------- */
function validateReviewForm(event) {
  event.preventDefault();

  const nameInput = document.getElementById("review-name");
  const ratingInput = document.getElementById("review-rating");
  const commentInput = document.getElementById("review-comment");

  let isValid = true;

  function showError(input, message) {
    const errorElement =
      input.parentElement.querySelector(".error-message");

    errorElement.textContent = message;
    input.classList.add("invalid");
    isValid = false;
  }

  function clearError(input) {
    const errorElement =
      input.parentElement.querySelector(".error-message");

    errorElement.textContent = "";
    input.classList.remove("invalid");
  }

  if (nameInput.value.trim().length < 3) {
    showError(nameInput, "Please enter your name.");
  } else {
    clearError(nameInput);
  }

  if (ratingInput.value === "") {
    showError(ratingInput, "Please select a rating.");
  } else {
    clearError(ratingInput);
  }

  if (commentInput.value.trim().length < 10) {
    showError(
      commentInput,
      "Please write a review with at least 10 characters."
    );
  } else {
    clearError(commentInput);
  }

  if (isValid) {
    customerReviews.push({
      name: nameInput.value.trim(),
      rating: parseInt(ratingInput.value),
      comment: commentInput.value.trim()
    });

    displayReviews(customerReviews);
    calculateAverageRating();

    reviewForm.reset();
    alert("Thank you for your review!");
  }
}

if (reviewForm) {
  reviewForm.addEventListener("submit", validateReviewForm);
}

/* ---------- 5. Filter Reviews by Rating ---------- */
if (ratingFilter) {
  ratingFilter.addEventListener("change", function () {
    const selectedRating = this.value;

    if (selectedRating === "all") {
      displayReviews(customerReviews);
    } else {
      const filteredReviews = customerReviews.filter(
        review => review.rating === parseInt(selectedRating)
      );

      displayReviews(filteredReviews);
    }
  });
}

/* ---------- 6. Load Reviews ---------- */
if (reviewsContainer) {
  displayReviews(customerReviews);
  calculateAverageRating();
}