// Product Catalogue.js console.log("JavaScript connected");

/* ---------------------------------------------------------
   1. Dynamic Bakery Product Listing
--------------------------------------------------------- */
const bakeryProducts = [
  {
    id: 1,
    name: "Chocolate Fudge Cake",
    category: "cakes",
    price: 450,
    description: "Rich chocolate sponge with smooth fudge icing.",
    image: "images/chocolate-cake.jpg"
  },
  {
    id: 2,
    name: "Vanilla Cupcakes",
    category: "cupcakes",
    price: 120,
    description: "Six vanilla cupcakes with buttercream frosting.",
    image: "images/vanilla-cupcakes.jpg"
  },
  {
    id: 3,
    name: "Fresh Bread Loaf",
    category: "bread",
    price: 45,
    description: "Soft white bread baked fresh every morning.",
    image: "images/bread-loaf.jpg"
  },
  {
    id: 4,
    name: "Croissants",
    category: "pastries",
    price: 75,
    description: "Buttery, flaky croissants baked daily.",
    image: "images/croissants.jpg"
  },
  {
    id: 5,
    name: "Red Velvet Cake",
    category: "cakes",
    price: 520,
    description: "Classic red velvet cake with cream cheese frosting.",
    image: "images/red-velvet-cake.jpg"
  },
  {
    id: 6,
    name: "Chocolate Muffins",
    category: "cupcakes",
    price: 90,
    description: "Four moist chocolate muffins with chocolate chips.",
    image: "images/chocolate-muffins.jpg"
  }
];

const productContainer = document.getElementById("product-list");
const searchInput = document.getElementById("product-search");
const categoryFilter = document.getElementById("category-filter");
const sortSelect = document.getElementById("product-sort");

function formatPrice(price) {
  return "R" + price.toFixed(2);
}

function displayProducts(products) {
  if (!productContainer) return;

  productContainer.innerHTML = "";

  if (products.length === 0) {
    productContainer.innerHTML = `
      <p class="no-results">No bakery products match your search.</p>
    `;
    return;
  }

  products.forEach(product => {
    const productCard = document.createElement("article");
    productCard.className = "product-card";

    productCard.innerHTML = `
      <img
        src="${product.image}"
        alt="${product.name}"
        class="product-image"
      >
      <h3>${product.name}</h3>
      <p>${product.description}</p>
      <p class="product-price">${formatPrice(product.price)}</p>
      <button class="btn order-btn" data-product="${product.name}">
        Enquire Now
      </button>
    `;

    productContainer.appendChild(productCard);
  });

  attachOrderButtonEvents();
}

function filterAndSortProducts() {
  if (!productContainer) return;

  let filteredProducts = [...bakeryProducts];

  const searchTerm = searchInput.value.toLowerCase().trim();
  const selectedCategory = categoryFilter.value;
  const selectedSort = sortSelect.value;

  if (searchTerm !== "") {
    filteredProducts = filteredProducts.filter(product =>
      product.name.toLowerCase().includes(searchTerm) ||
      product.description.toLowerCase().includes(searchTerm)
    );
  }

  if (selectedCategory !== "all") {
    filteredProducts = filteredProducts.filter(
      product => product.category === selectedCategory
    );
  }

  if (selectedSort === "price-low") {
    filteredProducts.sort((a, b) => a.price - b.price);
  } else if (selectedSort === "price-high") {
    filteredProducts.sort((a, b) => b.price - a.price);
  } else if (selectedSort === "name") {
    filteredProducts.sort((a, b) => a.name.localeCompare(b.name));
  }

  displayProducts(filteredProducts);
}

if (searchInput && categoryFilter && sortSelect) {
  searchInput.addEventListener("input", filterAndSortProducts);
  categoryFilter.addEventListener("change", filterAndSortProducts);
  sortSelect.addEventListener("change", filterAndSortProducts);

  displayProducts(bakeryProducts);
}

