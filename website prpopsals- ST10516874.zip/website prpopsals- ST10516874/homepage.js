// homepage.js console.log("JavaScript connected");


const welcomeModal = document.getElementById("welcome-modal");
const closeWelcomeButton = document.getElementById("close-welcome");
const welcomeContinueButton = document.getElementById("welcome-continue");

function openWelcomeModal() {
  if (!welcomeModal) return;

  welcomeModal.classList.add("active");
  document.body.style.overflow = "hidden";
}

function closeWelcomeModal() {
  if (!welcomeModal) return;

  welcomeModal.classList.remove("active");
  document.body.style.overflow = "";
}

window.addEventListener("load", openWelcomeModal);


if (closeWelcomeButton) {
  closeWelcomeButton.addEventListener("click", closeWelcomeModal);
}

if (welcomeContinueButton) {
  welcomeContinueButton.addEventListener("click", closeWelcomeModal);
}

if (welcomeModal) {
  welcomeModal.addEventListener("click", function (event) {
    if (event.target === welcomeModal) {
      closeWelcomeModal();
    }
  });
}

document.addEventListener("keydown", function (event) {
  if (event.key === "Escape") {
    closeWelcomeModal();
  }
});
/* ---------- 1. Time-Based Welcome Message ---------- */
const welcomeMessage = document.getElementById("welcome-message");

function displayWelcomeMessage() {
  if (!welcomeMessage) return;

  const currentHour = new Date().getHours();
  let greeting = "";

  if (currentHour < 12) {
    greeting = "Good morning";
  } else if (currentHour < 18) {
    greeting = "Good afternoon";
  } else {
    greeting = "Good evening";
  }

  welcomeMessage.textContent =
    greeting + "! Welcome to George Botha Park Bakery.";
}

displayWelcomeMessage();

/* ---------- 2. Featured Products Slider ---------- */
const featuredProducts = [
  {
    name: "Chocolate Fudge Cake",
    price: 450,
    image: "images/chocolate-cake.jpg"
  },
  {
    name: "Red Velvet Cake",
    price: 520,
    image: "images/red-velvet-cake.jpg"
  },
  {
    name: "Fresh Bread Loaf",
    price: 45,
    image: "images/bread-loaf.jpg"
  },
  {
    name: "Vanilla Cupcakes",
    price: 120,
    image: "images/vanilla-cupcakes.jpg"
  }
];

const sliderImage = document.getElementById("featured-image");
const sliderName = document.getElementById("featured-name");
const sliderPrice = document.getElementById("featured-price");
const nextProductButton = document.getElementById("next-product");
const previousProductButton = document.getElementById("previous-product");

let currentProductIndex = 0;

function displayFeaturedProduct() {
  if (!sliderImage || !sliderName || !sliderPrice) return;

  const product = featuredProducts[currentProductIndex];

  sliderImage.src = product.image;
  sliderImage.alt = product.name;
  sliderName.textContent = product.name;
  sliderPrice.textContent = "R" + product.price.toFixed(2);
}

function showNextProduct() {
  currentProductIndex++;

  if (currentProductIndex >= featuredProducts.length) {
    currentProductIndex = 0;
  }

  displayFeaturedProduct();
}

function showPreviousProduct() {
  currentProductIndex--;

  if (currentProductIndex < 0) {
    currentProductIndex = featuredProducts.length - 1;
  }

  displayFeaturedProduct();
}

if (nextProductButton) {
  nextProductButton.addEventListener("click", showNextProduct);
}

if (previousProductButton) {
  previousProductButton.addEventListener("click", showPreviousProduct);
}

displayFeaturedProduct();

/* ---------- 3. Bakery Opening Status ---------- */
const openingStatus = document.getElementById("opening-status");

function displayOpeningStatus() {
  if (!openingStatus) return;

  const now = new Date();
  const currentHour = now.getHours();
  const currentDay = now.getDay();

  /* Bakery open Monday to Saturday, 07:00 to 17:00 */
  const isOpen =
    currentDay >= 1 &&
    currentDay <= 6 &&
    currentHour >= 7 &&
    currentHour < 17;

  if (isOpen) {
    openingStatus.textContent = "We are currently open.";
    openingStatus.classList.add("open");
  } else {
    openingStatus.textContent =
      "We are currently closed. Opening hours: Monday to Saturday, 07:00 - 17:00.";
    openingStatus.classList.add("closed");
  }
}

displayOpeningStatus();

/* ---------- 4. Smooth Scrolling ---------- */
const navigationLinks = document.querySelectorAll('a[href^="#"]');

navigationLinks.forEach(link => {
  link.addEventListener("click", function (event) {
    const targetId = this.getAttribute("href");

    if (targetId === "#") return;

    const targetElement = document.querySelector(targetId);

    if (targetElement) {
      event.preventDefault();
      targetElement.scrollIntoView({
        behavior: "smooth",
        block: "start"
      });
    }
  });
});
/* ---------------------------------------------------------
   4. FAQ Accordion
--------------------------------------------------------- */
const accordionHeaders = document.querySelectorAll(".accordion-header");

accordionHeaders.forEach(header => {
  header.addEventListener("click", function () {
    const accordionItem = this.parentElement;
    const accordionContent = this.nextElementSibling;

    accordionItem.classList.toggle("active");

    if (accordionItem.classList.contains("active")) {
      accordionContent.style.maxHeight = accordionContent.scrollHeight + "px";
    } else {
      accordionContent.style.maxHeight = "0";
    }
  });
});


