// Gallery.js console.log("JavaScript connected");

/* ---------------------------------------------------------
   3. Gallery Lightbox
--------------------------------------------------------- */
const galleryImages = document.querySelectorAll(".gallery-image");
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightbox-image");
const lightboxCaption = document.getElementById("lightbox-caption");
const closeLightboxButton = document.getElementById("close-lightbox");

galleryImages.forEach(image => {
  image.addEventListener("click", function () {
    if (!lightbox) return;

    lightboxImage.src = this.src;
    lightboxImage.alt = this.alt;
    lightboxCaption.textContent = this.alt;

    lightbox.classList.add("active");
    document.body.style.overflow = "hidden";
  });
});

function closeLightbox() {
  if (!lightbox) return;

  lightbox.classList.remove("active");
  document.body.style.overflow = "";
}

if (closeLightboxButton) {
  closeLightboxButton.addEventListener("click", closeLightbox);
}

if (lightbox) {
  lightbox.addEventListener("click", function (event) {
    if (event.target === lightbox) {
      closeLightbox();
    }
  });
}

document.addEventListener("keydown", function (event) {
  if (event.key === "Escape") {
    closeLightbox();
  }
});

/* =========================================================
   Sweet Crumbs Bakery - Customer Enquiry Chat Box
   ========================================================= */

const chatToggle = document.getElementById("chat-toggle");
const chatContainer = document.getElementById("chat-container");
const chatClose = document.getElementById("chat-close");
const chatForm = document.getElementById("chat-form");
const chatInput = document.getElementById("chat-input");
const chatMessages = document.getElementById("chat-messages");
const quickReplyButtons = document.querySelectorAll(".quick-reply");

/* ---------- Open and Close Chat ---------- */
if (chatToggle) {
  chatToggle.addEventListener("click", function () {
    chatContainer.classList.toggle("active");
  });
}

if (chatClose) {
  chatClose.addEventListener("click", function () {
    chatContainer.classList.remove("active");
  });
}

/* ---------- Add Messages to Chat ---------- */
function addCustomerMessage(message) {
  const messageElement = document.createElement("div");
  messageElement.className = "chat-message customer";

  const messageText = document.createElement("p");
  messageText.textContent = message;

  messageElement.appendChild(messageText);
  chatMessages.appendChild(messageElement);

  scrollChatToBottom();
}

function addBakeryMessage(message) {
  const messageElement = document.createElement("div");
  messageElement.className = "chat-message bakery";

  const messageText = document.createElement("p");
  messageText.textContent = message;

  messageElement.appendChild(messageText);
  chatMessages.appendChild(messageElement);

  scrollChatToBottom();
}

function scrollChatToBottom() {
  chatMessages.scrollTop = chatMessages.scrollHeight;
}

/* ---------- Automatic Bakery Responses ---------- */
function getBakeryResponse(customerMessage) {
  const message = customerMessage.toLowerCase();

  if (
    message.includes("opening") ||
    message.includes("open") ||
    message.includes("hours") ||
    message.includes("close")
  ) {
    return "We are open Monday to Saturday from 07:00 to 17:00. " +
      "We are closed on Sundays.";
  }

  if (
    message.includes("custom cake") ||
    message.includes("birthday cake") ||
    message.includes("wedding cake")
  ) {
    return "Yes, we make custom cakes for birthdays, weddings, " +
      "and special events. Please visit our enquiry page with " +
      "your date, design idea, and number of guests.";
  }

  if (
    message.includes("order") ||
    message.includes("buy") ||
    message.includes("purchase")
  ) {
    return "You can place an order on our Order Online page. " +
      "Add products to your order, enter your delivery details, " +
      "and continue to online payment.";
  }

  if (
    message.includes("deliver") ||
    message.includes("delivery") ||
    message.includes("shipping")
  ) {
    return "Yes, we offer local delivery. Delivery availability " +
      "and fees depend on your address. Please provide your " +
      "delivery area when placing an order.";
  }

  if (
    message.includes("price") ||
    message.includes("cost") ||
    message.includes("how much")
  ) {
    return "Our prices depend on the product and size. For example, " +
      "fresh bread starts from R45, cupcakes from R120, and custom " +
      "cakes are quoted according to your design.";
  }

  if (
    message.includes("vegan") ||
    message.includes("gluten") ||
    message.includes("allergy")
  ) {
    return "We offer selected vegan and allergy-friendly options. " +
      "Please send us your dietary requirements before ordering so " +
      "we can confirm availability.";
  }

  if (
    message.includes("payment") ||
    message.includes("pay") ||
    message.includes("card")
  ) {
    return "You can pay securely online through our payment provider " +
      "after placing your order. We do not store your card details " +
      "on our website.";
  }

  if (
    message.includes("contact") ||
    message.includes("email") ||
    message.includes("phone")
  ) {
    return "You can contact us through the Contact page or send an " +
      "email to info@sweetcrumbsbakery.co.za.";
  }

  if (
    message.includes("hello") ||
    message.includes("hi") ||
    message.includes("good morning") ||
    message.includes("good afternoon")
  ) {
    return "Hello! How can we assist you with your bakery enquiry today?";
  }

  return "Thank you for your enquiry. A member of our bakery team " +
    "will assist you shortly. You can also visit our Contact page " +
    "to send us a detailed message.";
}

/* ---------- Handle Customer Message ---------- */
function handleCustomerMessage(message) {
  if (message.trim() === "") return;

  addCustomerMessage(message);

  setTimeout(function () {
    const bakeryResponse = getBakeryResponse(message);
    addBakeryMessage(bakeryResponse);
  }, 800);
}

/* ---------- Chat Form Submission ---------- */
if (chatForm) {
  chatForm.addEventListener("submit", function (event) {
    event.preventDefault();

    const customerMessage = chatInput.value;
    handleCustomerMessage(customerMessage);

    chatInput.value = "";
  });
}

/* ---------- Quick Reply Buttons ---------- */
quickReplyButtons.forEach(button => {
  button.addEventListener("click", function () {
    const quickMessage = this.dataset.message;
    handleCustomerMessage(quickMessage);
  });
});