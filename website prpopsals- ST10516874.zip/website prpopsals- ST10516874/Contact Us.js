// Contact Us.js console.log("JavaScript connected");

/* ---------------------------------------------------------
   5. Form Validation
--------------------------------------------------------- */
const enquiryForm = document.getElementById("enquiry-form");
const contactForm = document.getElementById("contact-form");

function showError(input, message) {
  const errorElement = input.parentElement.querySelector(".error-message");

  if (errorElement) {
    errorElement.textContent = message;
    input.classList.add("invalid");
  }
}

function clearError(input) {
  const errorElement = input.parentElement.querySelector(".error-message");

  if (errorElement) {
    errorElement.textContent = "";
    input.classList.remove("invalid");
  }
}

function validateName(nameInput) {
  const nameValue = nameInput.value.trim();

  if (nameValue === "") {
    showError(nameInput, "Please enter your full name.");
    return false;
  }

  if (nameValue.length < 3) {
    showError(nameInput, "Your name must be at least 3 characters long.");
    return false;
  }

  clearError(nameInput);
  return true;
}

function validateEmail(emailInput) {
  const emailValue = emailInput.value.trim();
  const emailPattern = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

  if (emailValue === "") {
    showError(emailInput, "Please enter your email address.");
    return false;
  }

  if (!emailPattern.test(emailValue)) {
    showError(emailInput, "Please enter a valid email address.");
    return false;
  }

  clearError(emailInput);
  return true;
}

function validatePhone(phoneInput) {
  const phoneValue = phoneInput.value.trim();
  const phonePattern = /^[0-9+\s()-]{10,15}$/;

  if (phoneValue === "") {
    showError(phoneInput, "Please enter your phone number.");
    return false;
  }

  if (!phonePattern.test(phoneValue)) {
    showError(phoneInput, "Please enter a valid phone number.");
    return false;
  }

  clearError(phoneInput);
  return true;
}

function validateMessage(messageInput) {
  const messageValue = messageInput.value.trim();

  if (messageValue === "") {
    showError(messageInput, "Please enter a message.");
    return false;
  }

  if (messageValue.length < 10) {
    showError(messageInput, "Your message must be at least 10 characters long.");
    return false;
  }

  clearError(messageInput);
  return true;
}

function validateEnquiryForm(event) {
  event.preventDefault();

  const nameInput = document.getElementById("enquiry-name");
  const emailInput = document.getElementById("enquiry-email");
  const phoneInput = document.getElementById("enquiry-phone");
  const productInput = document.getElementById("enquiry-product");
  const messageInput = document.getElementById("enquiry-message");

  const isNameValid = validateName(nameInput);
  const isEmailValid = validateEmail(emailInput);
  const isPhoneValid = validatePhone(phoneInput);
  const isMessageValid = validateMessage(messageInput);

  if (isNameValid && isEmailValid && isPhoneValid && isMessageValid) {
    const enquirySummary = `
      Thank you, ${nameInput.value.trim()}.

      Your enquiry about ${productInput.value} has been received.
      Our bakery team will contact you at ${emailInput.value.trim()}
      regarding availability and pricing.
    `;

    alert(enquirySummary);
    enquiryForm.reset();
  }
}

function validateContactForm(event) {
  event.preventDefault();

  const nameInput = document.getElementById("contact-name");
  const emailInput = document.getElementById("contact-email");
  const messageTypeInput = document.getElementById("contact-type");
  const messageInput = document.getElementById("contact-message");

  const isNameValid = validateName(nameInput);
  const isEmailValid = validateEmail(emailInput);
  const isMessageValid = validateMessage(messageInput);

  if (isNameValid && isEmailValid && isMessageValid) {
    const recipientEmail = "info@sweetcrumbsbakery.co.za";

    const subject = encodeURIComponent(
      "Website Contact Message - " + messageTypeInput.value
    );

    const body = encodeURIComponent(
      "Name: " + nameInput.value.trim() +
      "\nEmail: " + emailInput.value.trim() +
      "\nMessage Type: " + messageTypeInput.value +
      "\n\nMessage:\n" + messageInput.value.trim()
    );

    window.location.href =
      "mailto:" + recipientEmail +
      "?subject=" + subject +
      "&body=" + body;

    contactForm.reset();
  }
}

if (enquiryForm) {
  enquiryForm.addEventListener("submit", validateEnquiryForm);
}

if (contactForm) {
  contactForm.addEventListener("submit", validateContactForm);
}
